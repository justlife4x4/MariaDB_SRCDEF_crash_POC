#!/bin/bash
set -euo pipefail

mkdir -p /poc

sqlite3 /poc/odbc_poc.db <<'SQL'
CREATE TABLE IF NOT EXISTS t (
  id INTEGER PRIMARY KEY,
  v  TEXT
);
INSERT INTO t(v) VALUES ('seed-row');
SQL

chmod 0666 /poc/odbc_poc.db

